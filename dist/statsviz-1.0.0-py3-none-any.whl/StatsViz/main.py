import tkinter as tk
import interfaceRoot

root = tk.Tk()
main = interfaceRoot.RootWindow(root)
root.mainloop()