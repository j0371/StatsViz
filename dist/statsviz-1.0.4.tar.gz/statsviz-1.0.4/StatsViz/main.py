import tkinter as tk
from . import interfaceRoot

root = tk.Tk()
main = interfaceRoot.RootWindow(root)
root.mainloop()