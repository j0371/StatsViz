#StatsViz

This program allows you to load in data from a csv and plot various graphs
based on the CSV's data. It also allows you to save/load those plots to
a file

This project was created by Marcus Higgins for Senior project (CSCI 487)
at The University of Mississippi during the spring semester of 2019.